#pragma once

#include "helpers/pad.hpp"

class IViewRender
{
	PAD(1416);
	float smokeAlpha;
};