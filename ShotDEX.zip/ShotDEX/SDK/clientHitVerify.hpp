#pragma once

#include "math/Vector.hpp"

struct ClientHitVerify_t
{
	Vec3 m_pos;
	float m_time;
	float m_expire;
};