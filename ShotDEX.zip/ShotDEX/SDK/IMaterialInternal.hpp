#pragma once

#include "material.hpp"

class IMaterialInternal : public IMaterial
{

};