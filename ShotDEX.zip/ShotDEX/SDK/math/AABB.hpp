#pragma once

#include "Vector.hpp"

struct AABB_t
{
	Vec3 m_minBounds;
	Vec3 m_maxBounds;
};