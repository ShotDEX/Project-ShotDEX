#pragma once

class IPhysicsSurfaceProps;