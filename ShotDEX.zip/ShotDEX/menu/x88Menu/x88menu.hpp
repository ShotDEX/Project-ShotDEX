#pragma once

namespace x88Menu
{
	void draw();
	void updateKeys();
	void setStyles();
};