#pragma once

namespace tabs::settings
{
	void draw();
}