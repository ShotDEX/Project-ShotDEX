#pragma once

namespace tabs::aim
{
	void draw();
}