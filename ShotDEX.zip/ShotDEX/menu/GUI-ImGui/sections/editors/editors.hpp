#pragma once

namespace tabs::editors
{
	void draw();
}