#pragma once

namespace styleEditor
{
	void draw();
}