#include "chamsEditor.hpp"

#include <cheats/features/visuals/chams/editor.hpp>

void chamsEditor::draw()
{
	materialEditor::draw();
}