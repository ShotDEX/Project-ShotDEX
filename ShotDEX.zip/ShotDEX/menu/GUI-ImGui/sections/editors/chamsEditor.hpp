#pragma once

namespace chamsEditor
{
	void draw();
}