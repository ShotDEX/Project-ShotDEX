#pragma once

namespace tabs::misc
{
	void draw();
}