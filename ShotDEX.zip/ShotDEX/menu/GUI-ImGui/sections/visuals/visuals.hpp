#pragma once

namespace tabs::visuals
{
	void draw();
}