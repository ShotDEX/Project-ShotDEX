#pragma once

#include "../imguiaddons.hpp"

#include <render/render.hpp>
#include <render/fonts/icon.hpp>
#include <config/vars.hpp>
#include <deps/magic_enum/prettyNames.hpp>