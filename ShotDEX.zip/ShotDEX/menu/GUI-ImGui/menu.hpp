#pragma once

namespace ImGuiMenu
{
	void draw();
	void updateKeys();
	void setStyles();

	inline bool active{ true };
};