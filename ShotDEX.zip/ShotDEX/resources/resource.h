//{{NO_DEPENDENCIES}}
// Plik do��czany wygenerowany przez �rodowisko Microsoft Visual C++.
// U�ywany przez: csgo-legit.rc
//
#define IDR_VMT_FILE1                   101
#define IDR_VTF_FILE1                   102
#define IDR_VTF_FILE2                   103
#define IDR_VMT_FILE2                   104
#define IDR_VMT_FILE3                   105
#define IDR_VTF_FILE3                   106
#define IDR_VMT_FILE4                   107
#define IDR_VTF_FILE4                   108
#define IDR_VMT_FILE5                   109
#define IDR_VTF_FILE5                   110
#define IDR_VMT_FILE6                   111
#define IDR_VTF_FILE6                   112

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
