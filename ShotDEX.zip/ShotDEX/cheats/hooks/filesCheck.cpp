#include "filesCheck.hpp"

hooks::FilesCheck::value hooks::FilesCheck::hook(HACK_FAST_ARGS)
{
	return 1; // 2 is kick
}