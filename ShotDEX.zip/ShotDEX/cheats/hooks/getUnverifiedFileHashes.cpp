#include "getUnverifiedFileHashes.hpp"

hooks::GetUnverifiedFileHashes::value hooks::GetUnverifiedFileHashes::hook(HACK_FAST_ARGS, int maxFiles)
{
	return 0;
}