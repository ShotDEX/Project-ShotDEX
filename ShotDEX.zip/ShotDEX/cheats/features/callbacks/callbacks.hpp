#pragma once

// not used! See examples inside
namespace callbacks
{
	void init();
	void shutdown();
};