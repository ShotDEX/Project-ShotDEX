#pragma once

namespace AimbotDraw
{
	void draw();
};