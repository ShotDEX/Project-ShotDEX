#pragma once

class CUserCmd;

namespace triggerbot
{
	void run(CUserCmd* cmd);
};
