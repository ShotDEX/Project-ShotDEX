#pragma once

namespace bulletTracer
{
	void draw();
}
