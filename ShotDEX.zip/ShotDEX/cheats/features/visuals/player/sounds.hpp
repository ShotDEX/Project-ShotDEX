#pragma once

class Player_t;

namespace sound
{
	void draw();
	void findBest(Player_t* ent);
	void pushSteps(Player_t* ent);
};
