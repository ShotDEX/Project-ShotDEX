#pragma once

namespace playerVisuals
{
	void draw();
	void roundRestart();
}
