#pragma once

enum FrameStage;

namespace toneController
{
	void run(FrameStage stage);
	void grabberDefault();
	void shutdown();
}
