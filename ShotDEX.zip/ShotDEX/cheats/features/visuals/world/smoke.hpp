#pragma once

namespace smoke
{
	void draw();
}
