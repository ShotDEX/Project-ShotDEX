#pragma once

namespace weather::menu
{
	void draw();
}