#pragma once

namespace zeus
{
	void draw();
	void init();
	void shutdown();
}
