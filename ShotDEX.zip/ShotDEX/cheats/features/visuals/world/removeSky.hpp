#pragma once

namespace sky
{
	void run();
	void init();
}
