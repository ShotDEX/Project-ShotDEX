#pragma once

namespace grenadeWarning
{
	void draw();
}