#pragma once

enum FrameStage;

namespace fogController
{
	void run(FrameStage stage);
	void shutdown();
}
