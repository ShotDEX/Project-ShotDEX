#pragma once

namespace projectiles
{
	void draw();
}
