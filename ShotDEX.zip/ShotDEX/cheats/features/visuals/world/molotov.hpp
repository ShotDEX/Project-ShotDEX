#pragma once

namespace molotov
{
	void draw();
}
