#pragma once

namespace bulletImpacts
{
	void draw();
}
