#pragma once

namespace dropped
{
	void draw();
}
