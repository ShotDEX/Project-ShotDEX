#pragma once

namespace modulateColor
{
	void run(void* thisptr, float* r, float* g, float* b);
};
