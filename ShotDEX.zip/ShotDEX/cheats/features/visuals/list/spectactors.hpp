#pragma once

namespace spectactor
{
	void draw();
	void reset();
}