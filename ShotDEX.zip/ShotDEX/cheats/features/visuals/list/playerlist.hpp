#pragma once

namespace playerList
{
	void draw();
}