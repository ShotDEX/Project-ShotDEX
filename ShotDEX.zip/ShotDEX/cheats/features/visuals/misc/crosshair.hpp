#pragma once

namespace crosshair
{
	void init();
	void draw();
	void shutdown();
};