#pragma once

namespace trails
{
	void draw();
}