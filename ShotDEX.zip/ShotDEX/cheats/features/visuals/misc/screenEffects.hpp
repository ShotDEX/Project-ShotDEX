#pragma once

class CViewSetup;

namespace screenEffects
{
	void run([[maybe_unused]] CViewSetup* view);
	void initMaterials();
}