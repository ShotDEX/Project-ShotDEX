#pragma once

enum FrameStage;

namespace test
{
	void run(FrameStage stage);
	void draw();
}