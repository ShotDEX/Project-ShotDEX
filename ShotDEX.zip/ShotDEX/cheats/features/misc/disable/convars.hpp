#pragma once

namespace convars
{
	void run();
	void shutdown();
}