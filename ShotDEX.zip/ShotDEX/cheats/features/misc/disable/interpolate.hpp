#pragma once

enum FrameStage;

namespace interpolate
{
	void run(FrameStage stage);
};