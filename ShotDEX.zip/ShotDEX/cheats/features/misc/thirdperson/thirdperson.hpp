#pragma once

class CViewSetup;

namespace thirdperson
{
	void run([[maybe_unused]] CViewSetup* view);
	void updateKeys();
};
