#pragma once

namespace setup
{
	bool init(void* instance);
	void shutdown(void* instance);
	void looper(void* instance);
};